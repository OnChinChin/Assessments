﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AIE_Assessment_Exercise_08
{
    class PowerUp : GameObject
    {
        public PowerUp() : base()
        {

        }

        public override void Draw()
        {
            Console.Write("?");
        }

    }
}
